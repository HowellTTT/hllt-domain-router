// Listen for when the user types "hllt" followed by a space/tab in the address bar
chrome.omnibox.onInputEntered.addListener((text) => {
  // Replace this placeholder with your real website URL later if you'd like!
  let targetUrl = "https://www.google.com"; 
  
  if (text) {
    // If they typed something specific like "hllt/dashboard"
    if (text.startsWith("dashboard")) {
      targetUrl = "https://www.google.com/search?q=HLLT+Dashboard";
    } else if (text.startsWith("admin")) {
      targetUrl = "https://www.google.com/search?q=HLLT+Admin";
    } else {
      // General search or custom subpage path
      targetUrl = "https://www.google.com/search?q=HLLT+" + encodeURIComponent(text);
    }
  }
  
  // Update the active browser tab to navigate to the destination
  chrome.tabs.update({ url: targetUrl });
});
